# DRAGON BALL LEGENDS Python Bot

install is simple

visit https://legends.codedbots.com/ and get a license key

install python 3.10+ (https://www.python.org/downloads/release/python-31011/)

run `python -m pip install requests`

now paste your license key into [codedbots.py](https://github.com/Mila432/DRAGON-BALL-LEGENDS-Python-Bot/blob/main/codedbots.py#L10)

now run `python main.py -h`



lets say you want to farm an ios account on global , you run it like this:

`main.py --region gl --device ios -e ecd1bb8b626d380e93748523485ef051`

do not try to cheat the system... your license will be banned
